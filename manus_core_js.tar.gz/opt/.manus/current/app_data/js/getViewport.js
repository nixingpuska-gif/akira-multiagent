() => {
  return { width: window.innerWidth, height: window.innerHeight }
}